import splashImage from "./splash.png";
import React,{useEffect,useState} from "react";
import {definePlugin,ServerAPI,staticClasses} from "@decky/ui";
type Item={name:string;command:string;category:string;description:string};
const field:React.CSSProperties={width:"100%",boxSizing:"border-box",background:"#202d40",border:"1px solid #30425b",borderRadius:6,color:"#edf4ff",padding:11,marginBottom:8};
const action:React.CSSProperties={background:"#1e9e83",color:"#fff",border:0,borderRadius:6,padding:"9px 12px",fontWeight:700};
function Panel({serverAPI}:{serverAPI:ServerAPI}){
 const [items,setItems]=useState<Item[]>([]),[q,setQ]=useState(""),[cat,setCat]=useState("All"),[name,setName]=useState(""),[cmd,setCmd]=useState(""),[note,setNote]=useState("");
 const refresh=async()=>{try{const r:any=await serverAPI.callPluginMethod("get_launchers",[]);setItems(r?.result||[])}catch{setNote("Unable to load shortcuts.")}};
 useEffect(()=>{refresh()},[]);
 const cats=["All",...Array.from(new Set(items.map(x=>x.category||"Other"))).sort()];
 const visible=items.filter(x=>(cat==="All"||x.category===cat)&&`${x.name} ${x.command} ${x.description}`.toLowerCase().includes(q.toLowerCase()));
 const save=async(next:Item[])=>{await serverAPI.callPluginMethod("save_launchers",[next]);setItems(next)};
 return <div style={{padding:8,color:"#edf4ff"}}>
 <img src={splashImage} alt="DeckHub — Made for gamers. By a gamer." style={{width:"100%",height:"auto",display:"block",borderRadius:10,marginBottom:14}}/><div style={{fontSize:24,fontWeight:800}}>DECK<span style={{color:"#65e6c2"}}>HUB</span></div><p style={{color:"#9eafc7",fontSize:12,letterSpacing:1}}>MADE FOR GAMERS. BY A GAMER.</p>
 <input style={field} value={q} onChange={e=>setQ(e.target.value)} placeholder="Search library…"/>
 <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:12}}>{cats.map(c=><button key={c} onClick={()=>setCat(c)} style={{...action,background:cat===c?"#1e9e83":"#192333"}}>{c}</button>)}</div>
 <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))",gap:9}}>{visible.map((x,i)=><div key={i} style={{background:"#202d40",border:"1px solid #30425b",borderRadius:10,padding:13}}>
 <b>{x.name}</b><div style={{color:"#65e6c2",fontSize:10,marginTop:3}}>{x.category}</div><p style={{color:"#9eafc7",fontSize:12,overflowWrap:"anywhere"}}>{x.description||x.command}</p>
 <button style={action} onClick={async()=>{try{await serverAPI.callPluginMethod("launch",[x.command]);setNote("Started "+x.name)}catch{setNote("Could not launch "+x.name)}}}>▶ Launch</button>
 <button style={{...action,background:"#2a3a50",marginLeft:6}} onClick={()=>save(items.filter((_,j)=>j!==i))}>Remove</button></div>)}</div>
 {!visible.length&&<p style={{color:"#9eafc7"}}>No matching shortcuts.</p>}
 <section style={{background:"#192333",padding:12,borderRadius:8,marginTop:16}}><b>Add shortcut</b>
 <input style={{...field,marginTop:10}} value={name} onChange={e=>setName(e.target.value)} placeholder="Display name"/>
 <input style={field} value={cmd} onChange={e=>setCmd(e.target.value)} placeholder="Command (e.g. heroic)"/>
 <button style={action} onClick={async()=>{if(!name.trim()||!cmd.trim()){setNote("Enter a name and command.");return}await save([...items,{name:name.trim(),command:cmd.trim(),category:"Gaming",description:""}]);setName("");setCmd("");setNote("Shortcut saved.")}}>＋ Save shortcut</button></section>
 {note&&<p style={{color:"#65e6c2",fontSize:12}}>{note}</p>}
 </div>
}
export default definePlugin((serverAPI:ServerAPI)=>({name:"DeckHub",title:<div className={staticClasses.Title}>DeckHub</div>,content:<Panel serverAPI={serverAPI}/>,icon:<span>🎮</span>,onDismount(){}}));
